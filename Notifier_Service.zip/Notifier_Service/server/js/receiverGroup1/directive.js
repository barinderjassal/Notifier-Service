/**
 * Created by Leon Cutler on 7/10/14.
 * Description:
 *
 */

define([
    'angular',
    'text!server/js/receiverGroup1/template.html',
    'server/js/receiverGroup1/controller'
], function(angular, template) {
    angular.module('NotifierRecieverGroup1')
        .directive('notifierRecieverViewOne', [function() {
            return {
                restrict: 'EAC',
                template: template,
                replace: true,
                scope: {		 
                    'config': '=?subnavConfig',
                    'name': '@?moduleName'		 
                },
                controller: 'NotifierRecieverControllerGroup1'
            };
        }])
});
