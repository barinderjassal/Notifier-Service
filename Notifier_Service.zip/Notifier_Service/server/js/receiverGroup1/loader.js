/**
 * Created by Leon Cutler on 2/13/15.
 * Description:
 *
 */
define([
    'server/js/receiverGroup1/directive'
], function () {
	
});