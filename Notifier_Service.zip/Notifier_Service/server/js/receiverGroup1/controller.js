/**
 * Created by Krishnaraj on 1/19/15.
 * Description:
 *
 */
define([
    'angular',
    'server/js/receiverGroup1/reciever',
], function(angular) {
    angular.module('NotifierRecieverGroup1')
        .controller('NotifierRecieverControllerGroup1', ['$scope', 'NotifierService', function($scope, NotifierService) {
                     
            NotifierService.registerGroup('Fullscreenview', 'GlobalSubnavFullview', function() {
                console.log('hide subnav logic');
                angular.element(document.querySelector('.hide-block-subnav')).toggleClass('hide');                 
            }); 
        }
    ]);
});
