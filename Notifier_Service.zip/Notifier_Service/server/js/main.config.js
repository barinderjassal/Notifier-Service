require.config({
    baseUrl:'/',
    paths:{
        'angular': '/server/bower_components/angular/angular',
        'domready': '/server/bower_components/requirejs-domready/domReady',
        'text': '/server/bower_components/requirejs-text/text',
        'app': '/server/js/app',
        'moduleLoader': '../../module/js/loader'
    },
    shim:{
        angular: {exports: 'angular'},
        moduleLoader : {
            deps : ['angular']
        }
    }
});

require(['domready', 'angular', 'app'], function(domReady, angular){
    domReady(function(){
        angular.bootstrap(document, ['app']);
    });
});