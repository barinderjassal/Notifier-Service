/**
 * Created by Leon Cutler on 7/10/14.
 * Description:
 *
 */

define([
    'angular',
    'text!server/js/sample/template.html',
    'server/js/sample/controller'
], function(angular, template) {
    angular.module('SampleNotifier')
        .directive('sampleNotifierServiceView', [function() {
            return {
                restrict: 'EAC',
                template: template,
                replace: true,
                scope: false,
                controller: 'SampleNotifierController'
            };
        }]);
});
