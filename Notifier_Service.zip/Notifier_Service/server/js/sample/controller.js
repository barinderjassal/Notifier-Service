/**
 * Created by Krishnaraj on 1/19/15.
 * Description:
 *
 */
define([
    'angular',
    'server/js/sample/sample',
], function(angular) {
    angular.module('SampleNotifier')
        .controller('SampleNotifierController', ['$scope', 'NotifierService',
            function($scope, NotifierService) {
                $scope.txtMessage = 'Module1 - Message3';
                $scope.nID = 0;
                $scope.ndeleteID = 0;
              
                $scope.customMessage = {
                    ID: $scope.nID,
                    orginalMessage: {
                        'message': $scope.txtMessage
                    },
                };
                
                $scope.deleteMessage = {
                    ID: $scope.deleteMsg,
                    orginalMessage: {
                        'message': $scope.txtMessage
                    },
                };
               
                $scope.$watch('txtMessage', function() {
                    $scope.customMessage = {
                        ID: $scope.nID,
                        orginalMessage: {
                            'message': $scope.txtMessage
                        },
                    };
                });
                
                $scope.$watch('nID', function() {
                    $scope.customMessage = {
                        ID: $scope.nID,
                        orginalMessage: {
                            'message': $scope.txtMessage
                        },
                    };
                });
                
                $scope.$watch('ndeleteID', function() {
                    $scope.deleteMessage = {
                        ID: $scope.ndeleteID,
                        orginalMessage: {
                            'message': $scope.txtMessage
                        },
                    };
                });
                
                $scope.sendMessage = function() {
                    if ($scope.txtMessage == '') {
                        alert('Please Insert messages')
                    } else {
                        NotifierService.sendmessage('NotifierReciever', {
                            callback: 'addmMessage',
                            config: $scope.customMessage
                        });
                        
                    }
                    $scope.nID += 1;
                    $scope.txtMessage = '';
                    
                };
                $scope.removeLastMessage = function() {
                    NotifierService.sendmessage('NotifierReciever', {
                        callback: 'clearLast',
                        config: $scope.deleteMessage,
                        message: 'Congratulations! Your message has been recieved successfully'
                    });
                    $scope.ndeleteID += 1;
                };

                $scope.intitalize = function(title) {
                    /*  NotifierService.sendmessage('NotifierReciever', {
                          callback: 'intitalize',
                          config: $scope.customMessage
                      });*/
                };
                
                $scope.toggleDiv = function () {
                    NotifierService.sendGroupMessage('Fullscreenview');
                };
                
                $scope.intitalize();
            }
        ]);
});
