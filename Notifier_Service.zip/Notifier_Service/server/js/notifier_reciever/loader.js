/**
 * Created by Leon Cutler on 2/13/15.
 * Description:
 *
 */
define([
    'server/js/notifier_reciever/directive'
], function () {
	
});