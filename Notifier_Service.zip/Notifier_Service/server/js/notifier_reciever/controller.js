/**
 * Created by Krishnaraj on 1/19/15.
 * Description:
 *
 */
define([
    'angular',
    'server/js/notifier_reciever/reciever',
], function(angular) {
    angular.module('NotifierReciever')
        .controller('NotifierRecieverController', ['$scope', 'NotifierService',
            function($scope, NotifierService) {
                $scope.messages = [
                    {
                        message: 'Module1 - Message1'
                    }, 
                    {
                        message: 'Module1 - Message2'
                    }
                ];
                
                /*Call back Function to push  mesages*/
                var addMessage = function(config) {
                        if (config != undefined && config != null && (typeof config === 'object')) {
                            $scope.messages.push(config.orginalMessage);
                        } else {
                            throw "undefined argument or mismatch variable type in intitalize callback function";
                        }
                    },
                    /*Callback function to Remove Messages*/
                    clearLast = function(config) {
                        if (config != undefined && config != null && (typeof config === 'object')) {
                            $scope.messages.pop();
                        } else {
                            throw "undefined argument or mismatch variable type in intitalize callback function";
                        }
                    },                    
                    /*Handler to recieve the messages*/
                    handler = function(params) {
                        if (params != undefined && params != null && (typeof params === 'object')) {
                            switch (params.callback) {
                                case 'addmMessage':
                                    addMessage(params.config);
                                    break;
                                case 'clearLast':
                                    clearLast(params.config);
                                    break;
                                default:
                                    throw "undefined params value in Notifier Callback";
                                    break;
                            }
                        } else {
                            throw "undefined argument or mismatch variable type in Notifier Callback";
                        }
                    };
                
                /*Register handler to Initiate service*/
                NotifierService.register('NotifierReciever', handler);
                
                /*
                NotifierService.registerGroup('Fullscreenview','NavigationFullview', function() {
                    
                    console.log('hide navigation logic');
                });
                */
                
            }
        ]);
});
