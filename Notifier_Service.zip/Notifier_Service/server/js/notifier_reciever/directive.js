/**
 * Created by Leon Cutler on 7/10/14.
 * Description:
 *
 */

define([
    'angular',
    'text!server/js/notifier_reciever/template.html',
    'server/js/notifier_reciever/controller'
], function(angular, template) {
    angular.module('NotifierReciever')
        .directive('notifierRecieverView', [function() {
            return {
                restrict: 'EAC',
                template: template,
                replace: true,
                scope: {		 
                    'config': '=?subnavConfig',
                    'name': '@?moduleName'		 
              },
                controller: 'NotifierRecieverController'
            };
        }])
});
