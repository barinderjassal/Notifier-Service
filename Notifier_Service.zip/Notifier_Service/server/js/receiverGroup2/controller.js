/**
 * Created by Krishnaraj on 1/19/15.
 * Description:
 *
 */
define([
    'angular',
    'server/js/receiverGroup2/reciever',
], function(angular) {
    angular.module('NotifierRecieverGroup2')
        .controller('NotifierRecieverControllerGroup2', ['$scope', 'NotifierService', function($scope, NotifierService) {
               
            NotifierService.registerGroup('Fullscreenview', 'GlobalHeaderFullView', function() {
                console.log('hide header logic');
                angular.element(document.querySelectorAll('.hide-block-header')).toggleClass('hide');
            });
        }
    ]);
});
