/**
 * Created by Leon Cutler on 7/10/14.
 * Description:
 *
 */

define([
    'angular',
    'text!server/js/receiverGroup2/template.html',
    'server/js/receiverGroup2/controller'
], function(angular, template) {
    angular.module('NotifierRecieverGroup2')
        .directive('notifierRecieverViewTwo', [function() {
            return {
                restrict: 'EAC',
                template: template,
                replace: true,
                scope: {		 
                    'config': '=?subnavConfig',
                    'name': '@?moduleName'		 
                },
                controller: 'NotifierRecieverControllerGroup2'
            };
        }])
});
