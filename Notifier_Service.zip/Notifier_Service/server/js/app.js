/**
 * Created by leon on 5/19/14.
 */

/*
 * defineRequirements - These are the loaders for all of the modules, or packages needed
 * angularRequirements - This is the list of module names that will be feed into the app
 */

var defineRequirements = [
    'angular',
    'moduleLoader',
    'server/js/sample/loader',
	'server/js/notifier_reciever/loader',
	'server/js/receiverGroup1/loader',
	'server/js/receiverGroup2/loader'
     
], angularRequirements = [
    'Notifier',
    'SampleNotifier',
	'NotifierReciever',
    'NotifierRecieverGroup1',
    'NotifierRecieverGroup2'
];

define('app', defineRequirements, function (angular) {
    var app = angular.module('app', angularRequirements);
});