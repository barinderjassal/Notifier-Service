define([
    'angular',
    'angularMocks',
    'module/js/directive'
], function (angular) {
    describe('Unit Test: Global Header Unit Test', function () {
        var $compile, $rootScope;
        beforeEach(module('NewModuleName'));
        beforeEach(inject(function(_$rootScope_, _$compile_){
            $rootScope = _$rootScope_;
            $compile = _$compile_;
        }));
        it('Should load the global access header', function(){
                var element = $compile("<div new-module-name-directive></div>")($rootScope);
                $rootScope.$digest();
                expect(element[0].getElementsByTagName('div').length).toBeGreaterThan(0);
            });
    });
});