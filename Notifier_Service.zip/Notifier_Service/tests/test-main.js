var allTestFiles = [];
var TEST_REGEXP = /(spec|test)\.js$/i;

var pathToModule = function(path) {
  return path.replace(/^\/base\//, '').replace(/\.js$/, '');
};

Object.keys(window.__karma__.files).forEach(function(file) {
  if (TEST_REGEXP.test(file)) {
    // Normalize paths to RequireJS module names.
    allTestFiles.push(pathToModule(file));
  }
});

require.config({
  // Karma serves files under /base, which is the basePath from your config file
  baseUrl: '/base',
  paths: {
    'angular': '/base/server/bower_components/angular/angular',
    'angularMocks': '/base/server/bower_components/angular-mocks/angular-mocks',
    'domready': '/base/server/bower_components/requirejs-domready/domReady',
    'text': '/base/server/bower_components/requirejs-text/text',
    'app': '/base/server/app',
    'headroom': '/base/server/bower_components/headroom.js/dist/headroom',
    'ngHeadroom': '/base/server/bower_components/headroom.js/dist/angular.headroom',
    'angularBootstrap': '/base/server/bower_components/angular-bootstrap/ui-bootstrap-tpls',
    'globalheader': '/base/module/js/loader'
  },
  shim:{
    angular: {exports: 'angular'},
    angularMocks: {
      deps: ['angular']
    },
    ngHeadroom: {
      deps: ['angular', 'headroom']
    },
    angularBootstrap: {
      deps: ['angular']
    },
    globalheader: {
      deps: ['angular']
    }
  },
  priority: [
    'angular'
  ],
  // dynamically load all test files
  deps: allTestFiles,

  // we have to kickoff jasmine, as it is asynchronous
  callback: window.__karma__.start
});
