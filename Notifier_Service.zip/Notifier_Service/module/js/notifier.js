/**
 * Created by Leon Cutler on 8/12/14.
 * Description:
 *
 */

define([

    'angular'

], function(angular) {

    angular.module('Notifier', [])
        .factory('NotifierService', [function() {
            var factoryAPI = {
                /**
                 * Notifier Message Center
                 * The Notifier is used to transfer commands between objects that can be in different scopes.
                 * Important Details:
                 * - Messages can start being sent as soon as this is loaded
                 * - if a client hasn't registered yet, then it will be stored in the messages queue until it is
                 * - As soon as a client is registered, we will send any messages through to the corresponding call
                 * - All clients and messages require an id attribute to properly route everything
                 * - Client Registry Requirements
                 *      id
                 *      callback
                 *      altcallback
                 * - Message Requirements
                 *      id
                 *      type
                 *      message
                 *      altflag (optional - used to trigger alt callback if true)
                 */
                registry: {},
                messages: {},
                groups: {},
                /**
                 * Register
                 * This registers callbacks for an object by ID
                 * @param id
                 * @param callback
                 * @param altcallback
                 * @param queueFlag Flag to keep messages in queue until ready to accept them - true will prevent sending
                 * @returns The number of messages delivered after it is registered
                 */
                register: function(id, callback, altcallback, queueFlag) {
                    factoryAPI.registry[id] = {
                        callback: callback,
                        altcallback: altcallback
                    };
                    //Queue
                    if (!queueFlag || queueFlag === 'undefined') {
                        return factoryAPI.deliverMessages(id); 
                    }
                },
                registerGroup: function(groupId, registryId, callback, altcallback, queueFlag) {
                    if (factoryAPI.groups[groupId] === undefined) {
                        //factoryAPI.groups[groupId] = new Array();
                        factoryAPI.groups[groupId] = [];
                    }
                    /*
                        check if that registryID is already in there if not then add
                    */
                    
                    if (factoryAPI.groups[groupId].indexOf(registryId) === -1) {
                        
                        factoryAPI.groups[groupId].push(registryId);
                    } else {
                        
                    }
                    factoryAPI.register(registryId, callback, altcallback, queueFlag);
                },
                /**
                 * Deliver Messages
                 * Checks to see if there are any messages in the queue to be delivered for a specific ID
                 * If there are any messages in the queue, deliver them
                 * @param id
                 * returns count of messages sent
                 */
                deliverMessages: function(id) {
                    if (factoryAPI.messages[id]) {
                        var count = 0;
                        if (factoryAPI.messages[id].length > 0) {
                            var temp, i;
                            for (i = 0; i < factoryAPI.messages[id].length; i++) {
                                temp = factoryAPI.messages[id].splice(0, 1)[0];
                                factoryAPI.sendmessage(temp.id, temp.message, temp.altflag);
                                count++;
                            }
                        }
                        return count;
                    }
                },
                sendmessage: function(id, message, altflag) {
                    if (factoryAPI.registry[id]) {
                        if (altflag) {
                            if (factoryAPI.registry[id].altcallback) {
                                factoryAPI.registry[id].altcallback(message);
                            } else {
                                throw 'Missing Alternate Callback from registered client';
                            }
                        } else {
                            if (factoryAPI.registry[id].callback) {
                                factoryAPI.registry[id].callback(message);
                            } else {
                                throw 'Missing Main Callback from registered client check registration details for id, callback, altcallback';
                            }
                        }
                    } else {
                        if (!factoryAPI.messages[id]) {
                            factoryAPI.messages[id] = [];
                        }
                        factoryAPI.messages[id].push({ id: id, message: message, altflag: altflag });
                    }
                },
                sendGroupMessage: function(groupId, message, altflag) {
                    if (!!factoryAPI.groups[groupId] && (factoryAPI.groups[groupId].length > 0)) {
                        var registryList = factoryAPI.groups[groupId];
                        for(var i = 0; i < registryList.length; i++) {
                            factoryAPI.sendmessage(registryList[i], message, altflag);
                        }
                    } else {
                        throw 'Invalid Group';
                    }
                },
                deregister: function(id) {
                    try {
                        delete factoryAPI.registry[id];
                    } catch (e) {
                        return false;
                    }
                },
                deregisterGroup : function(id){
                    if (!!factoryAPI.groups[id] && (factoryAPI.groups[id].length > 0)) {
                        var registryList = factoryAPI.groups[id];
                        for(var i = 0; i < registryList.length; i++) {
                            factoryAPI.deregister(registryList[i]);
                        }
                        delete factoryAPI.groups[id];
                    } else {
                        throw 'Invalid Group';
                    }
                }
            };
            return factoryAPI;
        }]);

});
