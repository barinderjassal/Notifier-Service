/**
 * Created by Leon Cutler on 11/12/14.
 * Description:
 *
 */
define([
    'module/js/notifier'
], function () {
});